﻿using Mahali.Models;

namespace Mahali.Repositories.Interfaces
{
    public interface IOrderProductsInterface : IGenericInterface<OrderProducts>
    {
    }
}
