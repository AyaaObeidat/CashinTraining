﻿using Mahali.Models;

namespace Mahali.Repositories.Interfaces
{
    public interface ILocationInterface : IGenericInterface<Location>
    {
    }
}
