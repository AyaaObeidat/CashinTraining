﻿using Mahali.Models;

namespace Mahali.Repositories.Interfaces
{
    public interface ILatestProductVisitedInterface : IGenericInterface<LatestProductsVisited>
    {
    }
}
