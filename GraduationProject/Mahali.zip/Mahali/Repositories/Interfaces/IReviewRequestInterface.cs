﻿using Mahali.Models;

namespace Mahali.Repositories.Interfaces
{
    public interface IReviewRequestInterface : IGenericInterface<ReviewRequest>
    {
    }
}
