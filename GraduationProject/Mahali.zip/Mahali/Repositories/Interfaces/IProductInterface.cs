﻿using Mahali.Models;

namespace Mahali.Repositories.Interfaces
{
    public interface IProductInterface : IGenericInterface<Product>
    {
    }
}
