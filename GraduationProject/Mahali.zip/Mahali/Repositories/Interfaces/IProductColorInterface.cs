﻿using Mahali.Models;

namespace Mahali.Repositories.Interfaces
{
    public interface IProductColorInterface : IGenericInterface<ProductColors>
    {
    }
}
