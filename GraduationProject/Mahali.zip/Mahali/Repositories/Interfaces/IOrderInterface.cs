﻿using Mahali.Models;

namespace Mahali.Repositories.Interfaces
{
    public interface IOrderInterface : IGenericInterface<Order>
    {
    }
}
