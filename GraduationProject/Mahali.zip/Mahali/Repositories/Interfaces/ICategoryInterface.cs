﻿using Mahali.Models;

namespace Mahali.Repositories.Interfaces
{
    public interface ICategoryInterface : IGenericInterface<Category>
    {
       
    }
}
