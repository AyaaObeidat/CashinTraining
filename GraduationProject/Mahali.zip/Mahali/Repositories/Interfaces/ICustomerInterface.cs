﻿using Mahali.Models;

namespace Mahali.Repositories.Interfaces
{
    public interface ICustomerInterface : IGenericInterface<Customer>
    {
    }
}
