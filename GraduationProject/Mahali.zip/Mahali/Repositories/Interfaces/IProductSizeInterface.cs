﻿using Mahali.Models;

namespace Mahali.Repositories.Interfaces
{
    public interface IProductSizeInterface :IGenericInterface<ProductSizes>
    {
    }
}
