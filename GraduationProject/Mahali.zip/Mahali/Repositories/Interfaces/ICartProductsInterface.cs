﻿using Mahali.Models;

namespace Mahali.Repositories.Interfaces
{
    public interface ICartProductsInterface : IGenericInterface<CartProducts>
    {
    }
}
