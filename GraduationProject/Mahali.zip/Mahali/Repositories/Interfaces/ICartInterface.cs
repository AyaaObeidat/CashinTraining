﻿using Mahali.Models;

namespace Mahali.Repositories.Interfaces
{
    public interface ICartInterface : IGenericInterface<Cart>
    {
    }
}
