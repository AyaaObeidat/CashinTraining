﻿using Mahali.Models;

namespace Mahali.Repositories.Interfaces
{
    public interface IDiscountInterface :IGenericInterface<Discount>
    {
    }
}
