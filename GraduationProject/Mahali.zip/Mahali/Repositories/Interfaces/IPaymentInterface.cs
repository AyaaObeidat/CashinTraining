﻿using Mahali.Models;

namespace Mahali.Repositories.Interfaces
{
    public interface IPaymentInterface : IGenericInterface<Payment>
    {
    }
}
