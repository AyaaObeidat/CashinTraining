﻿public enum RequestStatus
{
    Pending,
    Approved,
    Rejected
}