﻿public enum OrderType
{
    InStorePickup,
    Delivery
}