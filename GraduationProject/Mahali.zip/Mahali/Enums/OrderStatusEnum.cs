﻿public enum OrderStatus 
{ 
    Paid,
    Cancelled 
}