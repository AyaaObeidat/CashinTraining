﻿public enum Sizes
{
    ExtraSmall,
    Small,
    Medium ,
    Large ,
    ExtraLarge ,
    DoubleExtraLarge,
    TripleExtraLarge,
    OneSize,
    Default,
    US_36,
    US_37,
    US_38,
    US_39,
    US_40,
    US_41,
    US_42,
    US_43,
    US_44,
    US_45,
    US_46,
}


