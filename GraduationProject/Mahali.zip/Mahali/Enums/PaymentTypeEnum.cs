﻿public enum PaymentType 
{ 
    Cash,
    Visa
}