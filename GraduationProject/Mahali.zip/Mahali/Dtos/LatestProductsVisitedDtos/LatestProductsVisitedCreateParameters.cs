﻿namespace Mahali.Dtos.LatestProductsVisitedDtos
{
    public class LatestProductsVisitedCreateParameters
    {
        public Guid CustomerId { get;  set; }
        public Guid ProductId { get;  set; }
    }
}
