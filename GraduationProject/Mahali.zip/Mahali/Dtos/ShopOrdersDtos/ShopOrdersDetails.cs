﻿namespace Mahali.Dtos.ShopOrdersDtos
{
    public class ShopOrdersDetails
    {
        public Guid Id { get; set; }
        public int OrderId { get;  set; }
        public Guid ShopId { get;  set; }
    }
}
