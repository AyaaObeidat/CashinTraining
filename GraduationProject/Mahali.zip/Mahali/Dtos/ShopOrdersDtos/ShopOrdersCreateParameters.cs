﻿namespace Mahali.Dtos.ShopOrdersDtos
{
    public class ShopOrdersCreateParameters
    {
        public int OrderId { get;  set; }
        public Guid ShopId { get;  set; }
    }
}
