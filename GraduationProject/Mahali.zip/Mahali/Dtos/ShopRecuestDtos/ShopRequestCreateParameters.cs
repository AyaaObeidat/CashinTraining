﻿namespace Mahali.Dtos.ShopRecuestDtos
{
    public class ShopRequestCreateParameters
    {
        public Guid AdminId { get;  set; }
        public Guid ShopId { get;  set; }
    }
}
