﻿namespace Mahali.Dtos.ShopRecuestDtos
{
    public class ShopRequestListItems
    {
        public Guid ShopId { get; set; }
        public RequestStatus RequestStatus { get; set; }
    }
}
