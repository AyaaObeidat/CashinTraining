﻿namespace Mahali.Dtos.ProductDtos
{
    public class ProductDeleteParameters
    {
        
        public Guid ProductId { get; set; }
    }
}
