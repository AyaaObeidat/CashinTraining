﻿namespace Mahali.Dtos.ProductDtos
{
    public class ProductGetByParameter
    {
        public Guid ProductId { get; set; }
        public Guid CategoryId { get; set; }
    }
}
