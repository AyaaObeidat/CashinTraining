﻿namespace Mahali.Dtos.OrderProductsDtos
{
    public class OrderProductsListItems
    {
        public Guid Id { get; set; }
        public int OrderId { get; set; }
        public Guid ProductId { get; set; }
    }
}
