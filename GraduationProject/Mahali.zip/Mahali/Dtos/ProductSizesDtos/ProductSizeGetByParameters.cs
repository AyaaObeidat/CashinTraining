﻿namespace Mahali.Dtos.ProductSizesDtos
{
    public class ProductSizeGetByParameters
    {
        public Guid Id { get; set; }
    }
}
