﻿namespace Mahali.Dtos.ReportDtos
{
    public class ReportDeleteParameters
    {
        public Guid ShopId {  get; set; }   
    }
}
