﻿namespace Mahali.Dtos.ReportDtos
{
    public class ReportGetByParameters
    {
        public Guid ID { get; set; }
    }
}
