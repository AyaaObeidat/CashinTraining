﻿namespace Mahali.Dtos.AdminDtos
{
    public class AdminUpdateParameters
    {
      
        public string UserName { get; set; }
        public string CurrentPassword { get; set; }
        public string NewPassword { get; set; }
    }
}
