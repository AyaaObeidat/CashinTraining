﻿namespace Mahali.Dtos.AdminDtos
{
    public class AdminLogin
    {
        public string Password { get; set; }
        public string UserName_Email { get; set; }
    }
}
