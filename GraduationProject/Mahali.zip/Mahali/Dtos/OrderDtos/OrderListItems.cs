﻿namespace Mahali.Dtos.OrderDtos
{
    public class OrderListItems
    {
        public int Id { get; set; }
        public decimal TotalAmount { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}
