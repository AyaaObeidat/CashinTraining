﻿namespace Mahali.Dtos.LocationDtos
{
    public class LocationListItems
    {
        public Guid Id { get; set; }
        public string AddressText { get; set; }
        public string AddressDirection { get; set; }
    }
}
