﻿namespace Mahali.Dtos.CartDtos
{
    public class CartCreateParameters
    {
        public Guid CustomerId { get; set; }
    }
}
