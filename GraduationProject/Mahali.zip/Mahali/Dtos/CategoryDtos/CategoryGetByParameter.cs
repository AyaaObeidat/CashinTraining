﻿namespace Mahali.Dtos.CategoryDtos
{
    public class CategoryGetByParameter
    {
        public Guid CategoryId { get; set; }
    }
}
