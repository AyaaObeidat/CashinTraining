﻿namespace Mahali.Dtos.CategoryDtos
{
    public class CategoryDeleteParameters
    {
        public Guid CategoryId { get; set; }
    }
}
