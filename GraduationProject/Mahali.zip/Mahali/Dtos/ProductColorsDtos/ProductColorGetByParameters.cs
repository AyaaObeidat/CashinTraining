﻿namespace Mahali.Dtos.ProductColorsDtos
{
    public class ProductColorGetByParameters
    {
        public Guid Id { get; set; }
    }
}
