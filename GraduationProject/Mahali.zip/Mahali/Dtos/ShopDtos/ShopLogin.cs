﻿namespace Mahali.Dtos.ShopDtos
{
    public class ShopLogin
    {
        public string Password { get; set; }
        public string UserName_Email { get; set; }
    }
}
