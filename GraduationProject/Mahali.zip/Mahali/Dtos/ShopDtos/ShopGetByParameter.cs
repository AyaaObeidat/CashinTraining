﻿namespace Mahali.Dtos.ShopDtos
{
    public class ShopGetByParameter
    {
        public Guid ShopId { get; set; }
    }
}
